import { redirect } from "next/navigation"

export default function WhyMoneyTriggersAnxietyAlias() {
  redirect("/why-money-triggers-anxiety-dan-lobel.html")
}


