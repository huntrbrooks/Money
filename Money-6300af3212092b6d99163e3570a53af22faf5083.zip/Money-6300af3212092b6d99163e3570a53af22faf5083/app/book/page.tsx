import { redirect } from "next/navigation"

export default function BookRedirect() {
  redirect("/bookings")
}


